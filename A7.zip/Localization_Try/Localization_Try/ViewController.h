//
//  ViewController.h
//  Localization_Try
//

//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIButton *btnBuy;

- (IBAction)btnBuy:(id)sender;
@property (weak, nonatomic) IBOutlet UILabel *lbl;

@end

