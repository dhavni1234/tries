//
//  ViewController.m
//  Localization_Try
//

//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.lbl.text = NSLocalizedString(@"Book_Name", nil);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)btnBuy:(id)sender {
    UIAlertView *showAlert = [[UIAlertView alloc]initWithTitle:@"Message"
message:NSLocalizedString(@"BOOK_PURCHASE", @"Message")
delegate:nil
cancelButtonTitle:@"Ok"
otherButtonTitles:nil];
    [showAlert show];
};
@end
