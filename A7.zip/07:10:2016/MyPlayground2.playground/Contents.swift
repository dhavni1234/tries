//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

let animal = "Fox"
if animal == "Cat" || animal == "Dog" {
    print("Animal is a house pet.")
} else {
    print("Animal is not a hopuse pet.")
}

let hourOfDay = 12
let timeOfDay: String

if hourOfDay < 6 {
    timeOfDay = "Early morning"
} else if hourOfDay < 12 {
    timeOfDay = "Morning"
} else if hourOfDay < 17 {
    timeOfDay = "Afternoon"
} else if hourOfDay < 20 {
    timeOfDay = "Evening"
} else if hourOfDay < 24 {
    timeOfDay = "Late Evening"
} else {
    timeOfDay = "Invalid  Hour"
}
print(timeOfDay)

var hoursWorked = 45

var price = 0
if hoursWorked > 40 {
    let hoursOver40 = hoursWorked - 40
    price += hoursOver40 * 50
    hoursWorked -= hoursOver40
}
price += hoursWorked * 25
print(price)

let r = 0...5
print(r)

let b = 0..<5

let count = 10
var sum = 0
for i in 1...count {
    sum += i
}

var s = 0
for i in 0...5 {
    sum += i
}

let c = (1, 5, 0)
print(c)


let num = 12
switch num {
case 0:
    print("zero")
default:
    print("Non zero")
}

let num1 = 10
switch num1 {
case 10:
    print("ten")
default:
    break
}


let time = 10
let platform: String
switch time {
case 0, 1, 2, 3, 4 :
    print("Platform C")
case 5, 6, 7, 8 :
    print("Platform B")
case 9, 10 :
    print("platform A")
default :
    print("No train")
}

let aa = 6
let name : String
switch aa {
case 0...4 :
    print("Dont exist")
case 5...6 :
    print("Exist")
default :
    print("No")
}

let age = 21
let category: String
switch age {
case 0...2 :
    category = "Infant"
case 3...12 :
    category = "Child"
case 13...19 :
    category = "Teenager"
default :
    category = "Oldies"
 
}
