//
//  extraTableViewCell.m
//  try1
//
//  Created by Raghu Bansal on 9/20/16.
//  Copyright © 2016 Sourabh Sharma. All rights reserved.
//

#import "extraTableViewCell.h"

@implementation extraTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
