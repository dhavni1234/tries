//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

var sum = 1
repeat {
    sum = sum + (sum + 1)
} while sum < 1000

print(sum)
