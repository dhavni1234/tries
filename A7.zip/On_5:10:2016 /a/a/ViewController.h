//
//  ViewController.h
//  a
//
//  Created by Raghu Bansal on 9/22/16.
//  Copyright © 2016 XtreemSolution. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITextField *textFieldOutlet;


@end

