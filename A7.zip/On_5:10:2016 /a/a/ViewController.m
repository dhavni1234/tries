//
//  ViewController.m
//  a
//
//  Created by Raghu Bansal on 9/22/16.
//  Copyright © 2016 XtreemSolution. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
   // self.textFieldOutlet = [UITextField new];
    self.textFieldOutlet.placeholder = @"Password";
    self.textFieldOutlet.font = [UIFont systemFontOfSize:18.f];
    self.textFieldOutlet.secureTextEntry = YES;
    self.textFieldOutlet.returnKeyType = UIReturnKeyDone;
   // self.textFieldOutlet.delegate = self;
    self.textFieldOutlet.backgroundColor = [UIColor colorWithRed:255 green:255 blue:255 alpha:0.64];
    self.textFieldOutlet.layer.borderColor = [[UIColor lightGrayColor] CGColor];
    self.textFieldOutlet.layer.borderWidth = 1.0f;
    //CGFloat textFieldOutlet = 45.f;
    //CGFloat textFieldWidth = 300.f;
 //   self.textFieldOutlet.frame = CGRectMake(DIALOG_VIEW_WIDTH/2.f - textFieldWidth / 2.f, 240.f, textFieldWidth, textFieldHeight);
    
    UIImageView *icon = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"lock.png"]];
    icon.frame = CGRectMake(0, 0, 45.f, 45.f);
    icon.backgroundColor = [UIColor lightGrayColor];
    self.textFieldOutlet.leftView = icon;
    self.textFieldOutlet.leftViewMode = UITextFieldViewModeAlways;
    
    //[self.dialogView addSubview:self.passwordTextField];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
