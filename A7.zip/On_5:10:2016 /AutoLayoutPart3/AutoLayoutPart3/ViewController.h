//
//
// link: https://www.raywenderlich.com/115440/auto-layout-tutorial-in-ios-9-part-1-getting-started-2
//
//  In this I tried the constraints again with taking buttons to all corner including cente too.
//  ViewController.h
//  AutoLayoutPart3
//
//  Created by Raghu Bansal on 10/5/16.
//  Copyright © 2016 XtreemSolution. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

