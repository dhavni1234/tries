//
// In this I tried constraints by taking the 2 button in the view. 1st at center and another as a login button at the bottom.
// 1) For center button at center, I applied the constraints: height,width,vertically center in container and horizontally center in the container.
// 2) For Bottom Login button, I applied the constraints: height, width, vertical spacing from bottom, vertically center in the container. As I ahve not used the leading and trailing space as they stretches the size of the controller i.e. button.
//
//  ViewController.h
//  autoLayoutTry
//
//  Created by Raghu Bansal on 10/5/16.
//  Copyright © 2016 XtreemSolution. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

