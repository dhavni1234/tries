//
//In this I have tried only the 4 contraints that makes the card fit for view appearence and change the color of imageview to Green.
// The constraints are as: height, width, vertically in container and leading space only.
// Link used: https://www.youtube.com/watch?v=wJVjuALsJ0g
//
//  ViewController.h
//  AutoLayoutPart2
//
//  Created by Raghu Bansal on 10/5/16.
//  Copyright © 2016 XtreemSolution. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

