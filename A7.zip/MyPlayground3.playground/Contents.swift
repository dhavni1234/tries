//: Playground - noun: a place where people can play

import UIKit


enum colorName: String {
    case black, silver
}

let fill = colorName.black

enum cssColor {
    case named(colorName)
}

