//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
2+6
10-2
2*4
24/3
(2+6)


22 / 7
22.0/7.0
22/7.0
22.0/7

((8000 / (5 * 10)) - 32) >> (29 % 5)

350 / 5 + 2
(350/5 + 2)

max(5,10)
min(1,2,3,4,0.5)

sqrt (2.0)

let number : Int = 10
print(number)

var math: Int = 10

math = 60

math = 5

print(math)

math = 6000_000

var counter = 0


// Assignment

let myCost : Int = 5

var averageCost : Double = 5
averageCost = 15

let testNumber : Int
let evenOdd : Int
testNumber = 2
evenOdd = testNumber % 2

var answer : Int = 0
answer += 1
answer += 10
answer *= 10

var age : Int
age = 16
print(age)
age = 20
print(age)

let a: Int = 46
let b: Int = 10

let answer1: Int = (a * 100) + b
let answer2: Int = (a * 100) + (b * 100)

5 * 3 - 4 / 2 * 2
(5 * 3) - 4 / (2 * 2)
5 * (3 - 4) / (2 * 2)
5 * 3 - (4 / 2) * 2
5 * (3 - 4 / 2) * 2
5 * (3 - 4 / 2 * 2)

var integer: Int = 100
var decimal: Double = 10.2
integer = Int(decimal)

var message = "Hello " + "my name is"
let name = "Matt"
message += name

let mark: Character = "!"
message += String (mark)

var firstName: String = "Rajdeep"
var lastName: String = "Rathore"
var fullName: String = (firstName) + " " + (lastName)
firstName += lastName

let coordinates: (Int,Int) = (2,3)

let cordinates = (2, 3)

let co = (2.1, 3)

let x = co.0
let y = co.1

let coo = (x:2,y:1,z:2)
let xx = coo.0
let yy = coo.1
let zz = coo.2

let (x1, y1, _) = coo

let string: String = "Dog"

var ab = "Arab"
ab += "Gal"


let order = "cat" < "dog"


let reader: String = "Rajdeep"
let author: String = "Matt"
let authorIsReader = reader == author


let or = reader < author


















