//
//  TableViewCell.swift
//  thatsRideScreenSwift
//
//  Created by Raghu Bansal on 10/12/16.
//  Copyright © 2016 XtreemSolution. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {

    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblAddress: UILabel!
    @IBAction func btnEdit(_ sender: AnyObject) {
    }
    
    @IBAction func btnDelete(_ sender: AnyObject) {
    }
   
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
