//
//  CustomUITextField.h


#import <UIKit/UIKit.h>

@class CustomUITextField;


IB_DESIGNABLE // you can see what changes you are going to do (Story board).


@interface CustomUITextField : UITextField

@property(nonatomic) IBInspectable NSInteger cornerRadius;
@property(nonatomic) IBInspectable NSInteger borderWidth;
@property(nonatomic,strong) IBInspectable UIColor *borderColor;
@property(nonatomic,strong) IBInspectable UIImage *leftIcon;





@end
