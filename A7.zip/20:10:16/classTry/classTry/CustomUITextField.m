//
//  CustomUITextField.m
//  

//
#import "CustomUITextField.h"


static CustomUITextField *activeTextField;

@interface CustomUITextField()<UITextFieldDelegate>
{
    CALayer *bottomLine;
    UIView *leftLine;
    UIView *rightLine;
    
    UIImageView *leftIconView;
    UIView *leftContainerView;
    UIImageView *leftIconImageView;
    UIView *rightContainerView;
    UIImageView *rightIconImageView;
}

@end

@implementation CustomUITextField
@synthesize leftIcon,rightIcon,colorPlaceholder,colorBottomLine,heightBottomLine, activeColorBottomLine, offsetBottomLine;
@synthesize datePicker;

+ (CustomUITextField *)activeTextField{
    return activeTextField;
}

- (id)initWithFrame:(CGRect)frame
{
    if ((self = [super initWithFrame:frame])) {
        [self initialize];
        [self initToolbar];
    }
    return self;
}

- (id)initWithCoder:(NSCoder *)aDecoder
{
    if ((self = [super initWithCoder:aDecoder])) {
        // Initialization code
        [self initialize];
        [self initToolbar];
    }
    return self;
}

- (void) awakeFromNib
{
    [super awakeFromNib];
    [self initialize];
    [self initToolbar];
    [self addTarget:self action:@selector(editingBegan:) forControlEvents:UIControlEventEditingDidBegin];
    [self addTarget:self action:@selector(editingEnd:) forControlEvents:UIControlEventEditingDidEndOnExit];
    
}

- (IBAction)editingBegan:(id)sender{
    //    [[AppDelegate sharedDelegate] setIsTextFieldEditting:YES];
    activeTextField = self;
}

- (IBAction)editingEnd:(id)sender{
    //    [[AppDelegate sharedDelegate] setIsTextFieldEditting:YES];
    [self resignFirstResponder];
}


- (void)prepareForInterfaceBuilder{
    [self initialize];
}

- (instancetype)init
{
    if (self = [super init]) {
        [self initialize];
    }
    return self;
}

-(void)initialize
{
    self.tintColor = [UIColor greenColor];
    [self initializeView];
    [self addBottomLine];
    
    if(leftIcon)
    {
        [self addLeftIcon];
    }
    
    //if(rightIcon)
    //{
    //[self addRightIcon];
    //}
    //    self.delegate = self;
    
}

// placeholder position
/*- (CGRect)textRectForBounds:(CGRect)bounds {
 
 if(self.leftView != nil)
 {
 return CGRectInset(bounds, self.leftView.frame.size.width, 10);
 }
 else{
 return CGRectInset(bounds, 30, 10);
 }
 
 }*/

// text position
/*- (CGRect)editingRectForBounds:(CGRect)bounds {
 if(self.leftView != nil)
 {
 return CGRectInset(bounds, self.leftView.frame.size.width, 10);
 }
 else{
 return CGRectInset(bounds, 30, 10);
 }
 }*/



//-(void) drawPlaceholderInRect:(CGRect)rect  {
//
//    if (self.placeholder)
//    {
//        // color of placeholder text
//        UIColor *placeHolderTextColor = [UIColor lightGrayColor];
//        if(colorPlaceholder != nil)
//        {
//            placeHolderTextColor=colorPlaceholder;
//        }
//        CGSize drawSize = [self.placeholder sizeWithAttributes:[NSDictionary dictionaryWithObject:self.font forKey:NSFontAttributeName]];
//        CGRect drawRect = rect;
//        // verticially align text
//        drawRect.origin.y = (rect.size.height - drawSize.height) * 0.5;
//        // set alignment
//        NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
//        paragraphStyle.alignment = self.textAlignment;
//        // dictionary of attributes, font, paragraphstyle, and color
//        NSDictionary *drawAttributes = @{NSFontAttributeName: self.font,
//                                         NSParagraphStyleAttributeName : paragraphStyle,
//                                         NSForegroundColorAttributeName : placeHolderTextColor};
//        // draw
//        [self.placeholder drawInRect:drawRect withAttributes:drawAttributes];
//    }
//}

-(void)addBottomLine{
    bottomLine = [CALayer layer];
    leftLine = [[UIView alloc] init];
    rightLine = [[UIView alloc] init];
    
    CGFloat bottomHeight = bottomHeight;
    bottomLine.backgroundColor = colorBottomLine.CGColor;
    leftLine.backgroundColor = colorBottomLine;
    rightLine.backgroundColor = colorBottomLine;
    //self.backgroundColor = [UIColor redColor];
    bottomLine.frame = CGRectMake(offsetBottomLine, self.frame.size.height-heightBottomLine, self.frame.size.width, heightBottomLine);
    NSLog(@"maxY = %f frame.hight = %f",self.frame.size.width, self.frame.size.height);
    rightLine.frame = CGRectMake(self.frame.size.width-1, self.frame.size.height-5, 1, 5);
    leftLine.frame = CGRectMake(0, self.frame.size.height-5, 1, 5);
    
    
    [self.layer addSublayer:bottomLine];
    [self addSubview:rightLine];
    [self addSubview:leftLine];
    self.layer.masksToBounds = YES;
}

-(void)addLeftIcon
{
    leftContainerView = [[UIView alloc] init];
    //[vwContainer setBackgroundColor:[UIColor redColor]];
    
    leftIconImageView = [[UIImageView alloc] initWithImage:leftIcon];
    [leftIconImageView setBackgroundColor:[UIColor clearColor]];
    [leftContainerView addSubview:leftIconImageView];
    [self setLeftView:leftContainerView];
    [self setLeftViewMode:UITextFieldViewModeAlways];
}


-(void)addRightIcon
{
    //rightContainerView = [[UIView alloc] init];
    //rightIconImageView = [[UIImageView alloc] initWithImage:rightIcon];
    //[rightIconImageView setBackgroundColor:[UIColor clearColor]];
    //[rightContainerView addSubview:rightIconImageView];
    //[self setRightView:rightContainerView];
    //[self setRightViewMode:UITextFieldViewModeAlways];
}

-(void)drawRect:(CGRect)rect
{
    bottomLine.frame = CGRectMake(offsetBottomLine, self.frame.size.height-heightBottomLine, self.frame.size.width, heightBottomLine);
    rightLine.frame = CGRectMake(self.frame.size.width-1, self.frame.size.height-5, 1, 5);
    leftLine.frame = CGRectMake(0, self.frame.size.height-5, 1, 5);
    
    [leftContainerView setFrame:CGRectMake(0, 0, self.frame.size.height, self.frame.size.height)];
    
    [leftIconImageView setFrame:CGRectMake(self.frame.size.height/3, (self.frame.size.height/3), self.frame.size.height/3, self.frame.size.height/3)];
    //[rightContainerView setFrame:CGRectMake(self.frame.size.width - rightContainerView.frame.size.width, 0.0f, self.frame.size.height, self.frame.size.height)];
    //[rightIconImageView setFrame:CGRectMake(self.frame.size.height/3, (self.frame.size.height/3), self.frame.size.height/3, self.frame.size.height/3)];
    
    leftContainerView.frame  = CGRectMake(0, 0, self.frame.size.height, self.frame.size.height) ;
}


- (void)initToolbar{
    UIToolbar *toolbar = [[UIToolbar alloc] initWithFrame:CGRectMake(0, 0, 0, 44)];
    toolbar.barTintColor = [UIColor greenColor];
    
    UIBarButtonItem *button = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(doneButtonPressed:)];
    
    UIBarButtonItem *flex = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    
    toolbar.tintColor = [UIColor whiteColor];
    
    
    //    UIBarButtonItem *cancelButton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemCancel target:self action:@selector(cancelButtonPressed:)];
    //
    
    //    [cancelButton setTitleTextAttributes:@{NSForegroundColorAttributeName: THEME_BLUE_COLOR} forState:UIControlStateNormal];
    
    toolbar.items = @[flex, button];
    
    self.inputAccessoryView = toolbar;
}

- (IBAction)cancelButtonPressed:(UIButton *)sender{
    [activeTextField endEditing:YES];
    
}

- (IBAction)doneButtonPressed:(UIButton *)sender{
    //    [[AppDelegate sharedDelegate] setIsTextFieldEditting:YES];
    // Check if activeTextField is empty
    // Then set text from first index
    if(activeTextField.text.length == 0){
        
        // Check input view for selected text field.
        if ([activeTextField.inputView isKindOfClass:[UIPickerView class]]) {
            UIPickerView *pickerView = (UIPickerView *)activeTextField.inputView;
            activeTextField.text = [pickerView.delegate pickerView:pickerView titleForRow:0 forComponent:0];
        }
        else if ([activeTextField.inputView isKindOfClass:[UIDatePicker class]]){
            datePicker = (UIDatePicker *)activeTextField.inputView;
            
            if (datePicker.datePickerMode == UIDatePickerModeDate) {
                NSDateFormatter *dateFormatter = [NSDateFormatter new];
                [dateFormatter setDateFormat:@"dd-MM-yyyy"];
                activeTextField.text = [dateFormatter stringFromDate:datePicker.date];
            }
            else{
                NSDateFormatter *dateFormatter = [NSDateFormatter new];
                [dateFormatter setDateFormat:@"hh:mm a"];
                activeTextField.text = [[dateFormatter stringFromDate:datePicker.date] uppercaseString];
            }
        }
    }
    else if ([activeTextField.inputView isKindOfClass:[UIDatePicker class]]){
        datePicker = (UIDatePicker *)activeTextField.inputView;
        
        if (datePicker.datePickerMode == UIDatePickerModeDate) {
            NSDateFormatter *dateFormatter = [NSDateFormatter new];
            [dateFormatter setDateFormat:@"dd-MM-yyyy"];
            activeTextField.text = [dateFormatter stringFromDate:datePicker.date];
        }
        else{
            NSDateFormatter *dateFormatter = [NSDateFormatter new];
            [dateFormatter setDateFormat:@"hh:mm a"];
            activeTextField.text = [[dateFormatter stringFromDate:datePicker.date] uppercaseString];
        }
    }
    activeTextField.text = [activeTextField.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    [self.txtFieldDelegate respondsToSelector:@selector(didPressedDoneButton:)];
    if (_txtFieldDelegate) {
        [_txtFieldDelegate didPressedDoneButton:self];
    }
    [self resignFirstResponder];
}

//-(void)textFieldDidBeginEditing:(UITextField *)textField
//{
//    if (self.delegate) {
//        [self.delegate textFieldDidBeginEditing:textField];
//    }
//
//    bottomLine.backgroundColor = activeColorBottomLine.CGColor;
//    leftLine.backgroundColor = activeColorBottomLine;
//    rightLine.backgroundColor = activeColorBottomLine;
//}
//
//-(void)textFieldDidEndEditing:(UITextField *)textField
//{
//    bottomLine.backgroundColor = colorBottomLine.CGColor;
//    leftLine.backgroundColor = colorBottomLine;
//    rightLine.backgroundColor = colorBottomLine;
//}

- (void)initializeView{
    self.keyboardAppearance = UIKeyboardAppearanceDark;
    self.autocorrectionType = UITextAutocorrectionTypeNo;
    
    if (self.cornerRadious == 0) {
        self.cornerRadious = 5;
    }
    
    if (self.borderWidth == 0) {
        self.borderWidth = 1;
    }
    
    if (self.borderColor == nil) {
        self.borderColor = [UIColor whiteColor];
    }
    
    
    self.layer.borderColor = self.borderColor.CGColor;
    self.layer.borderWidth = self.borderWidth;
    self.layer.cornerRadius = self.cornerRadious;
    
    if (self.colorPlaceholder == nil) {
        self.colorPlaceholder = [UIColor blackColor];
    }
    
    [self setValue:self.colorPlaceholder forKeyPath:@"_placeholderLabel.textColor"];
}


@end
