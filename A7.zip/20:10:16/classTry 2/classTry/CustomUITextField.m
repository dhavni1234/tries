//
//  CustomUITextField.m
//  ThatRides
//
//  Created by Raghu Bansal on 9/22/16.
//  Copyright © 2016 XtreemSolution. All rights reserved.
//
#import "CustomUITextField.h"


static CustomUITextField *activeTextField;

@interface CustomUITextField()<UITextFieldDelegate>
{
    CALayer *bottomLine;
    UIView *leftLine;
    UIView *rightLine;
    
    UIImageView *leftIconView;
    UIView *leftContainerView;
    UIImageView *leftIconImageView;
    UIView *rightContainerView;
    UIImageView *rightIconImageView;
}

@end

@implementation CustomUITextField
@synthesize leftIcon;

+ (CustomUITextField *)activeTextField{
    return activeTextField;
}

- (id)initWithFrame:(CGRect)frame
{
    if ((self = [super initWithFrame:frame])) {
        [self initialize];
       
    }
    return self;
}

- (id)initWithCoder:(NSCoder *)aDecoder
{
    if ((self = [super initWithCoder:aDecoder])) {
        // Initialization code
        [self initialize];
       
    }
    return self;
}

- (void) awakeFromNib
{
    [super awakeFromNib];
    [self initialize];
    
    [self addTarget:self action:@selector(editingBegan:) forControlEvents:UIControlEventEditingDidBegin];
    [self addTarget:self action:@selector(editingEnd:) forControlEvents:UIControlEventEditingDidEndOnExit];
    
}

- (IBAction)editingBegan:(id)sender{
    //    [[AppDelegate sharedDelegate] setIsTextFieldEditting:YES];
    activeTextField = self;
}

- (IBAction)editingEnd:(id)sender{
    //    [[AppDelegate sharedDelegate] setIsTextFieldEditting:YES];
    [self resignFirstResponder];
}


- (void)prepareForInterfaceBuilder{
    [self initialize];
}

- (instancetype)init
{
    if (self = [super init]) {
        [self initialize];
    }
    return self;
}

-(void)initialize
{
    self.tintColor = [UIColor greenColor];
    [self initializeView];
    
    if(leftIcon)
    {
        [self addLeftIcon];
    }
    
    
}




-(void)addLeftIcon
{
    leftContainerView = [[UIView alloc] init];
    leftIconImageView = [[UIImageView alloc] initWithImage:leftIcon];
    [leftIconImageView setBackgroundColor:[UIColor clearColor]];
    [leftContainerView addSubview:leftIconImageView];
    [self setLeftView:leftContainerView];
    [self setLeftViewMode:UITextFieldViewModeAlways];
}

-(void)drawRect:(CGRect)rect
{
    
    rightLine.frame = CGRectMake(self.frame.size.width-1, self.frame.size.height-5, 1, 5);
    leftLine.frame = CGRectMake(0, self.frame.size.height-5, 1, 5);
    
    [leftContainerView setFrame:CGRectMake(0, 0, self.frame.size.height, self.frame.size.height)];
    
    [leftIconImageView setFrame:CGRectMake(self.frame.size.height/3, (self.frame.size.height/3), self.frame.size.height/3, self.frame.size.height/3)];
    
    leftContainerView.frame  = CGRectMake(0, 0, self.frame.size.height, self.frame.size.height) ;
}




- (IBAction)cancelButtonPressed:(UIButton *)sender{
    [activeTextField endEditing:YES];
    
}

- (void)initializeView{
    self.keyboardAppearance = UIKeyboardAppearanceDark;
    self.autocorrectionType = UITextAutocorrectionTypeNo;
    
    if (self.cornerRadius == 0) {
        self.cornerRadius = 5;
    }
    
    if (self.borderWidth == 0) {
        self.borderWidth = 1;
    }
    
    if (self.borderColor == nil) {
        self.borderColor = [UIColor whiteColor];
    }
    
    
    self.layer.borderColor = self.borderColor.CGColor;
    self.layer.borderWidth = self.borderWidth;
    self.layer.cornerRadius = self.cornerRadius;
    
    
    
    
}


@end
