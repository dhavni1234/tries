//
//  CustomUITextField.h
//  ThatRides
//
//  Created by Raghu Bansal on 9/22/16.
//  Copyright © 2016 XtreemSolution. All rights reserved.
//

#import <UIKit/UIKit.h>

@class CustomUITextField;

IB_DESIGNABLE

@protocol CustomUITextFieldDelegate <NSObject>

- (void)didPressedDoneButton:(CustomUITextField *)textField;

@end

@interface CustomUITextField : UITextField

@property(nonatomic) IBInspectable NSInteger cornerRadius;
@property(nonatomic) IBInspectable NSInteger borderWidth;
@property(nonatomic,strong) IBInspectable UIColor *borderColor;
@property(nonatomic,strong) IBInspectable UIImage *leftIcon;

@property(nonatomic) id <CustomUITextFieldDelegate> txtFieldDelegate;

+ (CustomUITextField *)activeTextField;


@end
