//
//  ViewController.h
//  classTry
//
//  Created by Raghu Bansal on 10/20/16.
//  Copyright © 2016 XtreemSolution. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (strong, nonatomic) IBOutlet UIView *txtFieldTesting;

@end

