//
//  ViewController.h
//  NSUserDefaults
//
//  Created by Raghu Bansal on 10/4/16.
//  Copyright © 2016 XtreemSolution. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UISwitch *btnSync;
- (IBAction)btnSync:(id)sender;
@property (weak, nonatomic) IBOutlet UISlider *sliderControl;
- (IBAction)sliderControl:(id)sender;
@property (weak, nonatomic) IBOutlet UILabel *lblSlider;
@property (weak, nonatomic) IBOutlet UILabel *lblSwitch;
@property (weak, nonatomic) IBOutlet UITextField *txtFiledData;
- (IBAction)btnSave:(id)sender;
- (IBAction)btnShow:(id)sender;

@end

