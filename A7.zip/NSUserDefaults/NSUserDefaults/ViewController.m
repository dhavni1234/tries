//http://stackoverflow.com/questions/7510123/is-there-any-limit-in-storing-values-in-nsuserdefaults
//http://stackoverflow.com/questions/3074483/save-string-to-the-nsuserdefaults
// custom class can also be saved in user defaults: http://stackoverflow.com/questions/2315948/how-to-store-custom-objects-in-nsuserdefaults
//
//  ViewController.m
//  NSUserDefaults
//
//  Created by Raghu Bansal on 10/4/16.
//  Copyright © 2016 XtreemSolution. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    [self setState];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)btnSync:(id)sender {
    UISwitch *s = (UISwitch*)sender;
    BOOL status = s.on;
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    [userDefaults setBool:status forKey:@"sync"];
    [userDefaults synchronize];
    self.lblSwitch.text = s.on?@"ON":@"OFF";
}

- (IBAction)sliderControl:(id)sender {
    UISlider *s = (UISlider*)sender;
    
    int value = (int)s.value;
    
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    [userDefaults setInteger:value forKey:@"syncDur"];
    [userDefaults synchronize];
    self.lblSlider.text = [NSString stringWithFormat:@"%d",value];
}

- (void)setState {
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    
    BOOL syncOn = [userDefaults boolForKey:@"sync"];
    self.btnSync.on = syncOn;
    
    int value = (int)[userDefaults integerForKey:@"syncDur"];
    self.lblSlider.text = [NSString stringWithFormat:@"%d",value]; // for saving the label slider value.
    self.sliderControl.value = value;
     
}

- (IBAction)btnSave:(id)sender {
    NSString *valueToSave = self.txtFiledData.text;
    [[NSUserDefaults standardUserDefaults] setObject:valueToSave forKey:@"preferenceName"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    self.txtFiledData.text = @"";
}

- (IBAction)btnShow:(id)sender {
    NSString *savedValue = [[NSUserDefaults standardUserDefaults]
                            stringForKey:@"preferenceName"];
    self.txtFiledData.text = [NSString stringWithFormat:@"%@",savedValue];
}
@end
