//
//  AppDelegate.h
//  NSUserDefaults
//
//  Created by Raghu Bansal on 10/4/16.
//  Copyright © 2016 XtreemSolution. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

