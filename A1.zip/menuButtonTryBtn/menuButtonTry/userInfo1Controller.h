//
//  userInfo1Controller.h
//  menuButtonTry
//
//  Created by Raghu Bansal on 10/25/16.
//  Copyright © 2016 XtreemSolution. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface userInfo1Controller : UIViewController
@property (weak, nonatomic) IBOutlet UIButton *btnGetBackOutlet;
- (IBAction)btnGetBack:(id)sender;
@property NSDictionary *userInfoDictOnController2;
@property (weak, nonatomic) IBOutlet UILabel *lblFullName;
@property (weak, nonatomic) IBOutlet UILabel *lblCity;
@property (weak, nonatomic) IBOutlet UILabel *lblMob;
@end
