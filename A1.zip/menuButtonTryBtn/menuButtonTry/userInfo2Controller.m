//
//  userInfo2Controller.m
//  menuButtonTry
//
//  Created by Raghu Bansal on 10/25/16.
//  Copyright © 2016 XtreemSolution. All rights reserved.
//

#import "userInfo2Controller.h"

@interface userInfo2Controller ()

@end

@implementation userInfo2Controller

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    NSLog(@"View Loaded: UserInfo2");
    NSLog(@"Data Received:%@",self.userInfoDictOnController3);
    
    NSString *firstName = [self.userInfoDictOnController3 valueForKey:@"firstName"];
    NSString *lastName = [self.userInfoDictOnController3 valueForKey:@"lastName"];
    self.lblFullName.text = [NSString stringWithFormat:@"%@ %@",firstName, lastName];
    self.lblCity.text = [self.userInfoDictOnController3 valueForKey:@"city"];
    self.lblMob.text = [self.userInfoDictOnController3 valueForKey:@"mob"];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)btnGetBack:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

@end
