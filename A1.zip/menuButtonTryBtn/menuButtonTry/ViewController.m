//
//  ViewController.m
//  menuButtonTry
//
//  Created by Raghu Bansal on 10/25/16.
//  Copyright © 2016 XtreemSolution. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
{
    NSDictionary *userInfo1Dict;
    NSDictionary *userInfo2Dict;
    NSDictionary *userInfo3Dict;
    NSArray *arrayAllUserInfo;
    int selectedIndex;
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.tableView.hidden = YES;
    NSDictionary *userInfo4Dict = @{@"firstName":@"Jack",
                                    @"lastName":@"Marvick",
                                    @"city":@"Dellas",
                                    @"mob":@"123",
                                    
                                    };
    NSDictionary *userInfo5Dict = @{@"firstName":@"Alma",
                                    @"lastName":@"Beptist",
                                    @"city":@"texas",
                                    @"mob":@"456",
                                    };
    NSDictionary *userInfo6Dict = @{@"firstName":@"John",
                                    @"lastName":@"Carter",
                                    @"city":@"Abu Dhabi",
                                    @"mob":@"789",
                                    };
    
    
    
    arrayAllUserInfo = [[NSArray alloc] initWithObjects:userInfo4Dict,userInfo5Dict,userInfo6Dict, nil];
    userInfo1Dict = userInfo4Dict;
    userInfo2Dict = userInfo5Dict;
    userInfo3Dict = userInfo6Dict;
    NSLog(@"userInfo1Dict value: %@",userInfo1Dict);
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return arrayAllUserInfo.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    MenuCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"] ;
    if(!cell)
        cell = [[MenuCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    NSDictionary *userInfoCollection  = [arrayAllUserInfo objectAtIndex:indexPath.row];
    cell.lblName.text = [userInfoCollection valueForKey:@"firstName"];
    NSLog(@"cell value: %@",cell.lblName.text);
    cell.lblCity.text = [userInfoCollection valueForKey:@"city"];
    cell.btndetailOutlet.tag = indexPath.row;
    
    // Here the selector is used to provide the button action functionality here as we have declared into TableViewcell, and we have to use it TableViewController.
    [cell.btndetailOutlet addTarget:self action:@selector(whatHappensOnClick:) forControlEvents:UIControlEventTouchUpInside];
    return cell;
}

// Code shows which row is selected.
//- (NSIndexPath*)tableView:(UITableView *)tableView willSelectRowAtIndexPath:(NSIndexPath *)indexPath {
//    selectedIndex = (int)indexPath.row;
//    NSLog(@"Index Selected %d",selectedIndex);
//    return indexPath;
//}

//Button action.
-(void)whatHappensOnClick:(UIButton*)sender
{
    if (sender.tag == 0)
    {
        userInfoController *UserInfo1 = (userInfoController*)[self.storyboard instantiateViewControllerWithIdentifier:@"button1"];
        [self.navigationController pushViewController:UserInfo1 animated:YES];
        UserInfo1.userInfoDictOnController1 = userInfo1Dict;
    }
    if (sender.tag == 1)
    {
        userInfo1Controller *UserInfo2 = (userInfo1Controller*)[self.storyboard instantiateViewControllerWithIdentifier:@"button2"];
        [self.navigationController pushViewController:UserInfo2 animated:YES];
        UserInfo2.userInfoDictOnController2 = userInfo2Dict;
    }
    if (sender.tag == 2)
    {
        userInfo2Controller *UserInfo3 = (userInfo2Controller*)[self.storyboard instantiateViewControllerWithIdentifier:@"button3"];
        [self.navigationController pushViewController:UserInfo3 animated:YES];
        UserInfo3.userInfoDictOnController3 = userInfo3Dict;
    }
    
    



}

- (IBAction)btnMenu:(id)sender {
    if (self.tableView.hidden == YES) {
        self.tableView.hidden = NO;
    }else {
        self.tableView.hidden = YES;

    }
    
    
}
@end
