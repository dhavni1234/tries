//
//  ViewController.h
//  menuButtonTry
//
//  Created by Raghu Bansal on 10/25/16.
//  Copyright © 2016 XtreemSolution. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MenuCell.h"
#import "userInfoController.h"
#import "userInfo1Controller.h"
#import "userInfo2Controller.h"

@interface ViewController : UIViewController <UITableViewDataSource,UITableViewDelegate>
- (IBAction)btnMenu:(id)sender;
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end

