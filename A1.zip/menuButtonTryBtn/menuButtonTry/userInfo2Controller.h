//
//  userInfo2Controller.h
//  menuButtonTry
//
//  Created by Raghu Bansal on 10/25/16.
//  Copyright © 2016 XtreemSolution. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface userInfo2Controller : UIViewController
@property (weak, nonatomic) IBOutlet UIButton *btnGetBack;
- (IBAction)btnGetBack:(id)sender;
@property NSDictionary *userInfoDictOnController3;
@property (weak, nonatomic) IBOutlet UILabel *lblFullName;
@property (weak, nonatomic) IBOutlet UILabel *lblCity;
@property (weak, nonatomic) IBOutlet UILabel *lblMob;
@end
