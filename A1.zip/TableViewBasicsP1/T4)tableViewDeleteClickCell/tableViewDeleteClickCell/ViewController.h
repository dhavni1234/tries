//
//  ViewController.h
//  tableViewDeleteClickCell
//


#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UITableViewDelegate,UITableViewDataSource>


@end

