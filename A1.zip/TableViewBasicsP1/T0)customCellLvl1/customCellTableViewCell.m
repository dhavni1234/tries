//
//  customCellTableViewCell.m
//  customCellTry1
//
//  Created by Raghu Bansal on 11/24/16.
//  Copyright © 2016 XtreemSolution. All rights reserved.
//

#import "customCellTableViewCell.h"

@implementation customCellTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
