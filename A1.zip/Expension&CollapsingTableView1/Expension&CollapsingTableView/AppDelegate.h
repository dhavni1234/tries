//
//  AppDelegate.h
//  Expension&CollapsingTableView
//
//  Created by Raghu Bansal on 11/10/16.
//  Copyright © 2016 XtreemSolution. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

