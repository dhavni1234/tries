//https://www.youtube.com/watch?v=WMzKg5oOZJ4
// This is better: http://sugartin.info/2011/07/20/447/
//  ViewController.m
//  Expension&CollapsingTableView
//


#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    [self loadCellInfo];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

// Table view code.
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (visibleRows.count > 0) {  // Code for the visibility of possible rows.
        return visibleRows.count;
    }
    return 0;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSDictionary *currentCell = [self getCurrentCellInfo: indexPath];
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if(cell == nil) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    }
    cell.textLabel.text = [currentCell valueForKey:@"cellTitle"]; // valueForKey is from plist.
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    NSInteger tappedRow = [visibleRows[indexPath.row]intValue];
    BOOL shouldExpandAndShow;
    if ([[cellInfo[tappedRow]valueForKey:@"isExpandable"] boolValue]){
        
        shouldExpandAndShow = false;
        
        if (![[cellInfo[tappedRow]valueForKey:@"isExpanded"] boolValue]) {
            shouldExpandAndShow = true;
        }
    }
    [cellInfo[tappedRow] setValue:[NSNumber numberWithBool:shouldExpandAndShow] forKey:@"isExpanded"];
    
    for (NSInteger i = tappedRow  + 1; i < (tappedRow + [[cellInfo[tappedRow] valueForKey:@"additionalRows"] intValue]); i++) {
        
        [cellInfo[i] setValue:[NSNumber numberWithBool:shouldExpandAndShow] forKey:@"isVisible"];
    }
    [self getVisibleRows];
    [self.tableView reloadSections:[NSIndexSet indexSetWithIndex:0] withRowAnimation:UITableViewRowAnimationFade];
}
-(void)loadCellInfo {
// Method to display cell info.

    if ([[NSFileManager defaultManager]fileExistsAtPath:[[NSBundle mainBundle] pathForResource:@"CellProperties" ofType:@"plist"]]) {
        cellInfo = [NSMutableArray arrayWithContentsOfFile:[[NSBundle mainBundle]pathForResource:@"CellProperties" ofType:@"plist"]];
    }
    [self getVisibleRows];
    [self.tableView reloadData];
}

- (void)getVisibleRows {
    visibleRows = [[NSMutableArray alloc]init];
    int i;
    for (i = 0; i < cellInfo.count; i++) {
        if ([[cellInfo [i] valueForKey:@"isVisible"] boolValue]) {
            [visibleRows addObject:[NSNumber numberWithInt:i]];
            
        }
    }
      
}

-(NSDictionary *)getCurrentCellInfo : (NSIndexPath *)IndexPath {
    NSDictionary *cellDictionary = cellInfo[[visibleRows [IndexPath.row] intValue]];
    return cellDictionary;
}



@end
