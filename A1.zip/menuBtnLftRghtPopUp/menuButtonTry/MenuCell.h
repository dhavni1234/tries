//
//  MenuCell.h
//  menuButtonTry
//

#import <UIKit/UIKit.h>

@interface MenuCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *lblName;
@property (weak, nonatomic) IBOutlet UILabel *lblCity;
@property (weak, nonatomic) IBOutlet UIButton *btndetailOutlet;
- (IBAction)btndetail:(id)sender;

@end
