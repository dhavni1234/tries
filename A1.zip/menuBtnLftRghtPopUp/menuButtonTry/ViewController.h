//
//  ViewController.h
//  menuButtonTry
//


#import <UIKit/UIKit.h>
#import "MenuCell.h"
#import "userInfoController.h"
#import "userInfo1Controller.h"
#import "userInfo2Controller.h"

@interface ViewController : UIViewController <UITableViewDataSource,UITableViewDelegate>
- (IBAction)btnMenu:(id)sender;
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet UITableView *tableViewRight;

@end

