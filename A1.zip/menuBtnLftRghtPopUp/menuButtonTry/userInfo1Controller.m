//
//  userInfo1Controller.m
//  menuButtonTry
//

#import "userInfo1Controller.h"

@interface userInfo1Controller ()

@end

@implementation userInfo1Controller

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    NSLog(@"View Loaded: UserInfo1");
    NSLog(@"Data Received:%@",self.userInfoDictOnController2);
    
    NSString *firstName = [self.userInfoDictOnController2 valueForKey:@"firstName"];
    NSString *lastName = [self.userInfoDictOnController2 valueForKey:@"lastName"];
    self.lblFullName.text = [NSString stringWithFormat:@"%@ %@",firstName, lastName];
    self.lblCity.text = [self.userInfoDictOnController2 valueForKey:@"city"];
    self.lblMob.text = [self.userInfoDictOnController2 valueForKey:@"mob"];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)btnGetBack:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}



@end
