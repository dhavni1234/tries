//
//  MenuCell.m
//  menuButtonTry
//
//  http://gabriel-tips.blogspot.in/2011/10/uitableview-display-and-hide-cells-as.html//

#import "MenuCell.h"

@implementation MenuCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

// In tableViewCell it works as view did load.
- (void)layoutSubviews {
    [super layoutSubviews];
    self.btndetailOutlet.layer.cornerRadius = 7;
    self.btndetailOutlet.layer.masksToBounds = YES;
    self.btndetailOutlet.layer.borderWidth = 1;
    if (self.btndetailOutlet.tag == 0) {
        [self.btndetailOutlet setTitle:@"User" forState:UIControlStateNormal];
    } else if (self.btndetailOutlet.tag == 1){
        [self.btndetailOutlet setTitle:@"Login" forState:UIControlStateNormal];
    } else if (self.btndetailOutlet.tag == 2){
        [self.btndetailOutlet setTitle:@"Code" forState:UIControlStateNormal];
    }
}

- (IBAction)btndetail:(id)sender {
    if (self.btndetailOutlet.tag == 0) {
        NSLog(@"Button Pressed1");
        
    }
    if (self.btndetailOutlet.tag == 1) {
        NSLog(@"Button Pressed2");
    }
    if (self.btndetailOutlet.tag == 2) {
        NSLog(@"Button Pressed3");
    }

    
}
@end
