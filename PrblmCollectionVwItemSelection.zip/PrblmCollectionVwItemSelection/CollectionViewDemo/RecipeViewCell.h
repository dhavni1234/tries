//
//  RecipeViewCell.h
//  CollectionViewDemo
//


#import <UIKit/UIKit.h>

@interface RecipeViewCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UIImageView *recipeImageView;

@end
