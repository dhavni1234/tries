//
//  RecipeCollectionViewController.h
//  CollectionViewDemo
//


#import <UIKit/UIKit.h>

@interface RecipeCollectionViewController : UICollectionViewController<UIImagePickerControllerDelegate, UINavigationControllerDelegate>

// declaration for image upload via gallery.
{
        UIImagePickerController *ipc;
    
}
- (IBAction)imageButtonAction:(id)sender;


@end
