//
//  SecondViewController.h
//  TryPCH


#import <UIKit/UIKit.h>
#import "ConstantFile.h"
//#import "PrefixHeader.pch"

@interface SecondViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIImageView *imageView;
@property (weak, nonatomic) IBOutlet UITextField *txtField1;

@end
