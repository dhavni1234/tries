//
//  ViewController.h
//  expMng
//


#import <UIKit/UIKit.h>
#import "expanseManagerController.h"

@interface ViewController : UIViewController
- (IBAction)btnEnter:(id)sender;
@property (weak, nonatomic) IBOutlet UITextField *txtFieldPassCode;


@end

