//
//  expenseController.h
//  expMng
//


#import <UIKit/UIKit.h>

@interface expenseController : UIViewController

@end
