//
//  deniedController.m
//  expMng
//
//  Created by Raghu Bansal on 11/29/16.
//  Copyright © 2016 XtreemSolution. All rights reserved.
//

#import "deniedController.h"

@interface deniedController ()
{
    NSTimer *timer;
    int count;
}

@end

@implementation deniedController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self.navigationController.navigationBar setHidden:YES];
    count = 0;
    timer = [NSTimer scheduledTimerWithTimeInterval:1.0f
                                              target:self
                                            selector:@selector(timerFired)
                                            userInfo:nil
                                             repeats:YES];
    

}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void)timerFired {
    count = count + 1;
    NSLog(@"%d",count);
    if (count == 10) {
        [timer invalidate];
        [self.navigationController popToRootViewControllerAnimated:YES];
    }
}



@end
