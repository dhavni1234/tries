//
//  deniedController.h
//  expMng
//
//  Created by Raghu Bansal on 11/29/16.
//  Copyright © 2016 XtreemSolution. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface deniedController : UIViewController

@end
