//  ViewController.m
//  expMng
//

#import "ViewController.h"

@interface ViewController ()
{
    NSString *passcode;
    int count;
    int attempt;

}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    passcode = @"1234";
    count = 0;
    
    
    }

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)viewWillAppear:(BOOL)animated {
    count = 0;
    attempt = 3;
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [self.view endEditing:YES];
}

//****Alert for Access Denied.*****
-(void)accessDenied {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"TEMPORARILY BLOCKED"
                                                                   message:@"You have reached maximum number of attempts! Please try after 10 secs"
                                                            preferredStyle:UIAlertControllerStyleAlert];
    
   /* //Alert action Replay.
    UIAlertAction *Ok =[UIAlertAction actionWithTitle:@"Ok"
                                                style:UIAlertActionStyleDefault
                                              handler:^(UIAlertAction *action){
                                                  [alert dismissViewControllerAnimated:YES completion:nil];
    **** for screen trf.****
    deniedController *denied = (deniedController*)[self.storyboard instantiateViewControllerWithIdentifier:@"denied"];
                                                  [self.navigationController pushViewController:denied animated:YES];
                                                  
                                                  
                                              }];
    
    [alert addAction:Ok];*/
    [self presentViewController:alert animated:YES completion:nil];
    
}


//****Alert for wrong pin.*****
- (void)wrongPinAlert {
     count = count + 1;
    attempt = attempt - 1 ;
    if (attempt == 0) {
        [self accessDenied];

    }
    UIAlertController *wrongPinAlert = [UIAlertController alertControllerWithTitle:@"Wrong PIN"
                                                                   message:[NSString stringWithFormat:@"Ooops Try With Correct PIN! \n ATTEMPT LEFT: %d",attempt ]
                                                            preferredStyle:UIAlertControllerStyleAlert];
    
    //Alert action Replay.
    UIAlertAction *Ok =[UIAlertAction actionWithTitle:@"Ok"
                                                   style:UIAlertActionStyleDefault
                                                 handler:^(UIAlertAction *action){
                                                     [wrongPinAlert dismissViewControllerAnimated:YES completion:nil];
    }];
    [wrongPinAlert addAction:Ok];
    [self presentViewController:wrongPinAlert animated:YES completion:nil];
    
}
//****Alert for right pin.****
- (void)alertRightPin {
    count = 0;

    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Verification Successfull"
                                                                   message:@"Congratulations you are verified!"
                                                            preferredStyle:UIAlertControllerStyleAlert];
    
    //Alert action Replay.
    UIAlertAction *Ok =[UIAlertAction actionWithTitle:@"Ok"
                                                style:UIAlertActionStyleDefault
                                              handler:^(UIAlertAction *action){
                                                  [alert dismissViewControllerAnimated:YES completion:nil];
    //**** for screen trf.****
    expanseManagerController *emc = (expanseManagerController*)[self.storyboard instantiateViewControllerWithIdentifier:@"expenseManager"];
                                                  [self.navigationController pushViewController:emc animated:YES];
                                                  
                                                  
                                              }];
    
    [alert addAction:Ok];
    [self presentViewController:alert animated:YES completion:nil];
    
}

 - (IBAction)btnEnter:(id)sender
    {
        if (count >= 3) {
            NSLog(@"****Your 3 attempts over");
            NSLog(@"count %d",count);
            [self accessDenied];
        }
        else {
        UIAlertController *controller = [UIAlertController alertControllerWithTitle:@"Authorization Required"
                            message:@"Please enter your PIN for authorization"
                            preferredStyle:UIAlertControllerStyleAlert];

            UIAlertAction *alertAction = [UIAlertAction actionWithTitle:@"Login"
                                                              style:UIAlertActionStyleDestructive
                                                            handler:^(UIAlertAction *action) {
                                                                NSLog(@"Login button tapped!");
                                                                NSLog(@"Textfield text - %@", controller.textFields.firstObject.text);
                                   
        if (controller.textFields.firstObject.text == [NSString stringWithFormat:@"%@",passcode]) {
            [self alertRightPin];
                                                                    
        } else {
                [self wrongPinAlert];
           NSLog(@"count increased by 1:%d",count);
                }

        }];
        
        
        [controller addAction:alertAction];
        
        [controller addTextFieldWithConfigurationHandler:^(UITextField *textField) {
            textField.placeholder = @"Enter Your PIN Here";
            textField.secureTextEntry = YES;
            textField.keyboardType = UIKeyboardTypeNumberPad;
            textField.textColor = [UIColor redColor];
            textField.textAlignment = NSTextAlignmentCenter;


        }];
        [self presentViewController:controller animated:YES completion:nil];
        }
    }

@end
