//http://swiftiostutorials.com/using-uialertcontroller-instead-good-old-uialertview/
//  ViewController.h
//  expMng
//


#import <UIKit/UIKit.h>
#import "expanseManagerController.h"

@interface ViewController : UIViewController
- (IBAction)btnEnter:(id)sender;
@property (weak, nonatomic) IBOutlet UITextField *txtFieldPassCode;

- (IBAction)btnAlert:(id)sender;


@end

