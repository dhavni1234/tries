//  ViewController.m
//  expMng
//

#import "ViewController.h"

@interface ViewController ()
{
    NSString *passcode;
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    passcode = @"1";
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)btnEnter:(id)sender {
    if (self.txtFieldPassCode.text == [NSString stringWithFormat:@"%@",passcode]) {
        [self alertRightPin];

    } else {
        [self alert];
    }
    
}
//**Alert for wrong pin.**
- (void)alert {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Wrong PassCode"
                                                                   message:@"Ooops Try With Correct Passcode!"
                                                            preferredStyle:UIAlertControllerStyleAlert];
    
    //Alert action Replay.
    UIAlertAction *Ok =[UIAlertAction actionWithTitle:@"Ok"
                                                   style:UIAlertActionStyleDefault
                                                 handler:^(UIAlertAction *action){
                                                     [alert dismissViewControllerAnimated:YES completion:nil];
                                                    
    }];
    [alert addAction:Ok];
    [self presentViewController:alert animated:YES completion:nil];
    
}
//Alert for right pin.
- (void)alertRightPin {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Login Successfull"
                                                                   message:@"Congratulations login successfull!"
                                                            preferredStyle:UIAlertControllerStyleAlert];
    
    //Alert action Replay.
    UIAlertAction *Ok =[UIAlertAction actionWithTitle:@"Ok"
                                                style:UIAlertActionStyleDefault
                                              handler:^(UIAlertAction *action){
                                                  [alert dismissViewControllerAnimated:YES completion:nil];
    //** for screen trf.**
    expanseManagerController *emc = (expanseManagerController*)[self.storyboard instantiateViewControllerWithIdentifier:@"expenseManager"];
                                                  [self.navigationController pushViewController:emc animated:YES];
                                                  
                                                  
                                              }];
    [alert addAction:Ok];
    [self presentViewController:alert animated:YES completion:nil];
    
}

 - (IBAction)btnAlert:(id)sender
    {
        UIAlertController *controller = [UIAlertController alertControllerWithTitle:@"Error!"
                                                                            message:@"Test error message"
                                                                     preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction *alertAction = [UIAlertAction actionWithTitle:@"Dismiss"
                                                              style:UIAlertActionStyleDestructive
                                                            handler:^(UIAlertAction *action) {
                                                                NSLog(@"Dismiss button tapped!");
                                                                NSLog(@"Textfield text - %@", controller.textFields.firstObject.text);
        if (controller.textFields.firstObject.text == [NSString stringWithFormat:@"%@",passcode]) {
            [self alertRightPin];
                                                                    
        } else {
                [self alert];
                }

        }];
        
        [controller addAction:alertAction];
        
        [controller addTextFieldWithConfigurationHandler:^(UITextField *textField) {
            textField.placeholder = @"Test";
            textField.textColor = [UIColor redColor];
        }];
        
        [self presentViewController:controller animated:YES completion:nil];
    }
@end
