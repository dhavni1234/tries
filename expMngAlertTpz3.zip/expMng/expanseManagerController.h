//
//  expanseManagerController.h
//  expMng
//

#import <UIKit/UIKit.h>
#import "IncomeController.h"
#import "expenseController.h"

@interface expanseManagerController : UIViewController
- (IBAction)btnIncome:(id)sender;
- (IBAction)btnExpense:(id)sender;

@end
