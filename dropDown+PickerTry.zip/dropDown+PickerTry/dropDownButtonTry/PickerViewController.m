//
//  PickerViewController.m
//  dropDownButtonTry
//
//  Created by Raghu Bansal on 11/11/16.
//  Copyright © 2016 XtreemSolution. All rights reserved.
//

#import "PickerViewController.h"

@interface PickerViewController ()
{
    NSArray *genderArray;
     NSArray *cityArray;
}

@end

@implementation PickerViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.

    cityArray = [[NSArray alloc]initWithObjects:@"Delhi",@"Mumbai",@"Chennai", nil];
    genderArray = [[NSArray alloc]initWithObjects:@"Male",@"Female",@"Transgender", nil];
    self.pickerView.hidden = YES;
    self.btnDoneOutlet.hidden = YES;
    
    

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
    
}
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    
    [self.view endEditing:YES];
}

//Needed to prevent keyboard from opening
-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
    
    // do here everything you want
    NSLog(@"Pressed on TextField!");
    self.pickerView.hidden = NO;
    self.btnDoneOutlet.hidden = NO;

    [self.view endEditing:YES]; // Hide keyboard
    
    return NO;
}

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}

-(NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{ 
    return [genderArray count];
}
-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    self.textField.text =[genderArray objectAtIndex:row];
}

-(NSString*)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    return [genderArray objectAtIndex:row];
}




- (IBAction)textFieldAction:(id)sender {
    self.pickerView.hidden = NO;
    self.btnDoneOutlet.hidden = NO;
}

- (IBAction)btnDone:(id)sender {
    self.pickerView.hidden = YES;
    self.btnDoneOutlet.hidden = YES;
}

@end
