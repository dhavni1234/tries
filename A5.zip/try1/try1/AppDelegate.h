//
//  AppDelegate.h
//  try1
//
//  Created by Sourabh Sharma on 9/20/16.
//  Copyright © 2016 Sourabh Sharma. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

