//
//  ViewController.h
//  try1
//

//

#import <UIKit/UIKit.h>
#import "BookingDetail.h"


@interface ViewController : UIViewController <UITableViewDelegate,UITableViewDataSource>
@property (weak, nonatomic) IBOutlet UITableView *bookingTableView;



@end

