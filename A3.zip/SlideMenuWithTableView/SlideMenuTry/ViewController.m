//VideoLink: https://www.youtube.com/watch?v=snYmY138RIs
//  ViewController.m
//  SlideMenuTry
//


#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)btnLeft:(id)sender {
    AppDelegate *app = [[UIApplication sharedApplication]delegate];
    [app.drawerController toggleDrawerSide:MMDrawerSideLeft animated:YES completion:nil];
    }
- (IBAction)btnRight:(id)sender {
//    AppDelegate *app = [[UIApplication sharedApplication]delegate];
//    [app.drawerController toggleDrawerSide:MMDrawerSideLeft animated:YES completion:nil];


}

@end
