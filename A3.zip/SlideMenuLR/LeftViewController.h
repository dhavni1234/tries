//
//  LeftViewController.h
//  SlideMenuTry
//


#import <UIKit/UIKit.h>

@interface LeftViewController : UIViewController

@end
