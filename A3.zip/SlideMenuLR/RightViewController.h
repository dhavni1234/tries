//
//  RightViewController.h
//  SlideMenuTry
//


#import <UIKit/UIKit.h>

@interface RightViewController : UIViewController

@end
